from django.urls import path
from . import views
urlpatterns=[
   path('register/',views.register),
path('login/',views.login),
path('display/',views.display),
path('fileupload/',views.file),
path('filedisplay/',views.filedisplay),
path('header/',views.header),
path('footer/',views.footer),
path('',views.index),
path('cupload/',views.cupload),
path('cdisplay/',views.cdis),
path('clogin/',views.clog),
]
