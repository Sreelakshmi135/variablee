from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import *
from .models import *


# Create your views here.

def register(request):
    if request.method=='POST':
        a=regform(request.POST)
        if a.is_valid():
            nm= a.cleaned_data['name']
            em = a.cleaned_data['email']
            ps = a.cleaned_data['password']
            cp= a.cleaned_data['cpassword']
            if(ps==cp):
                b=regmodel(name=nm,email=em,password=ps)
                b.save()
                return redirect(login)
            else:
                return HttpResponse("")
        else:
            return HttpResponse("")
    else:
        return render(request,'registration.html')


def login(request):
    if request.method=='POST':
        a=logform(request.POST)
        if a.is_valid():
            em=a.cleaned_data['email']
            ps=a.cleaned_data['password']
            b=regmodel.objects.all()
            for i in b:
                if em==i.email and ps==i.password:
                    return HttpResponse("login sucess")
                else:
                     return HttpResponse("login failed")
    else:
        return render(request,"login.html")



def display(request):
    a=regmodel.objects.all()
    return render(request,'display.html',{'a':a})



def file(request):
    if request.method=='POST':
        a=fileform(request.POST,request.FILES)
        if a.is_valid():
            nm=a.cleaned_data['iname']
            pr=a.cleaned_data['iprice']
            des=a.cleaned_data['des']
            im=a.cleaned_data['image']
            b=filemodel(iname=nm,iprice=pr,des=des,image=im)
            b.save()
            return redirect(filedisplay)
        else:
            return HttpResponse("failed")
    else:
        return render(request,'fileupload.html')


def filedisplay(request):
    x=filemodel.objects.all()
    li=[]
    name=[]
    disc1=[]
    price=[]
    for i in x:
        path=i.image
        li.append(str(path).split("/")[-1])
        nm=i.iname
        name.append(nm)
        dis=i.des
        disc1.append(dis)
        pri=i.iprice
        price.append(pri)
    mylist=zip(li,name,disc1,price)
    return render(request,'bcart.html',{'mylist':mylist})


#navbar

def header(request):
    return render(request,'bheader.html')

def footer(request):
    return render(request,'bfooter.html')

def index(request):
    return render(request,'bindex.html')


def cupload(request):
    if request.method=='POST':
        a=cregisterform(request.POST,request.FILES)
        if a.is_valid():
            nm=a.cleaned_data['name']
            em=a.cleaned_data['email']
            ps=a.cleaned_data['password']
            ph=a.cleaned_data['phone']
            fl=a.cleaned_data['file']
            b=cregistermodel(name=nm,email=em,password=ps,phone=ph,file=fl)
            b.save()
            return redirect(clog)
        else:
            return HttpResponse("failed")
    else:
        return render(request,'cregistration.html')

def cdis(request):
    x=cregistermodel.objects.all()

    ln=[]
    le=[]
    lp=[]
    lph=[]
    im = []
    for i in x:
        path=i.file
        im.append(str(path).split('/')[-1])
        ln.append(i.name)
        le.append(i.email)
        lp.append(i.password)
        lph.append(i.phone)
        mylist=zip(ln,le,lp,lph,im)
        return render(request,'cview.html',{'mylist':mylist})

def clog(request):
    if request.method=='POST':
        a=clogform(request.POST)
        if a.is_valid():
            nm=a.cleaned_data['email']
            ps=a.cleaned_data['password']
            b=cregistermodel.objects.all()
            for i in b:
                if (i.email==nm and i.password==ps):
                    return redirect(cdis)
            else:
                    return HttpResponse("login failed")
    else:
        return render(request,'clogin.html')
    