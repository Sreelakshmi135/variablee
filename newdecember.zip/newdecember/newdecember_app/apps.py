from django.apps import AppConfig


class NewdecemberAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newdecember_app'
