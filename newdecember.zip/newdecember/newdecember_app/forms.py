from django import forms
class regform(forms.Form):
    name=forms.CharField(max_length=30)
    email=forms.EmailField()
    password=forms.CharField(max_length=30)
    cpassword=forms.CharField(max_length=30)


class logform(forms.Form):
    email=forms.EmailField()
    password=forms.CharField(max_length=30)


class fileform(forms.Form):
    iname=forms.CharField(max_length=30)
    iprice=forms.IntegerField()
    des=forms.CharField(max_length=20)
    image=forms.FileField()


class cregisterform(forms.Form):
    name=forms.CharField(max_length=30)
    email=forms.EmailField()
    password=forms.CharField(max_length=30)
    phone=forms.IntegerField()
    file=forms.FileField()

class clogform(forms.Form):
    email=forms.EmailField()
    password=forms.CharField(max_length=30)
