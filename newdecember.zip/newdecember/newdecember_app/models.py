from django.db import models

# Create your models here.
class regmodel(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField()
    password=models.CharField(max_length=30)

class filemodel(models.Model):
    iname=models.CharField(max_length=20)
    iprice=models.IntegerField()
    des=models.CharField(max_length=30)
    image=models.FileField(upload_to="newdecember_app/static")

class cregistermodel(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField()
    password=models.CharField(max_length=30)
    phone=models.IntegerField()
    file=models.FileField(upload_to="newdecember_app/static")